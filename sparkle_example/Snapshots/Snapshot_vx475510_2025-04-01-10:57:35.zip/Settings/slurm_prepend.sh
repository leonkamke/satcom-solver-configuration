#!/bin/bash

source ~/.bashrc