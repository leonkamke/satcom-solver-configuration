#!/bin/bash

conda activate sparkle